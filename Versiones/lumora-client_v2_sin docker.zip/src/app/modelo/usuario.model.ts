export interface Usuario {
  nombre: string;
  usuario: string;
  correo: string;
  clave: string;
  fecha: string;
  direccion: string;
}
