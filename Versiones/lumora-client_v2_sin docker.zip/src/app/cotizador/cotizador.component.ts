import { Component } from '@angular/core';

@Component({
  selector: 'app-cotizador',
  standalone: true,
  imports: [],
  templateUrl: './cotizador.component.html',
  styleUrl: './cotizador.component.css'
})
export class CotizadorComponent {

}
