import { Component } from '@angular/core';

@Component({
  selector: 'app-seguimiento',
  standalone: true,
  imports: [],
  templateUrl: './seguimiento.component.html',
  styleUrl: './seguimiento.component.css'
})
export class SeguimientoComponent {

}
