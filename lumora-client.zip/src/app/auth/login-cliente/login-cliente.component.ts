import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';

declare var bootstrap: any;

@Component({
  selector: 'app-login-cliente',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login-cliente.component.html',
  styleUrls: ['./login-cliente.component.css']
})
export class LoginClienteComponent {
  usuario: string = '';
  clave: string = '';
  mensaje: string = '';

  constructor(private router: Router) {}

  loginCliente() {
    if (this.usuario === 'cliente' && this.clave === '1234') {
      this.mensaje = '';

      // ✅ Cerrar modal manualmente
      const modalElement = document.getElementById('loginClienteModal');
      const modalInstance = bootstrap.Modal.getInstance(modalElement);
      modalInstance?.hide();

      // ✅ Eliminar el fondo negro si queda
      const backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) backdrop.remove();

      // ✅ Navegar al componente cliente
      this.router.navigate(['/cliente']);
    } else {
      this.mensaje = 'Usuario o clave incorrecta.';
    }
  }

  // ✅ Redirigir al recuperar contraseña y cerrar el modal
  irARecuperar(event: Event) {
    event.preventDefault();
    const modalElement = document.getElementById('loginClienteModal');
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    modalInstance?.hide();

    const backdrop = document.querySelector('.modal-backdrop');
    if (backdrop) backdrop.remove();

    this.router.navigate(['/forgot-password']);
  }
}
