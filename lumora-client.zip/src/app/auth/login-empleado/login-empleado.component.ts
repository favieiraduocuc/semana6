import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

declare var bootstrap: any;

@Component({
  selector: 'app-login-empleado',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login-empleado.component.html',
  styleUrls: ['./login-empleado.component.css']
})
export class LoginEmpleadoComponent {
  usuario: string = '';
  clave: string = '';
  mensaje: string = '';

  constructor(private router: Router) {}

  loginEmpleado() {
    if (this.usuario === 'empleado' && this.clave === '4321') {
      this.mensaje = '';

      // ✅ Cierra el modal de empleado manualmente
      const modalElement = document.getElementById('loginEmpleadoModal');
      const modalInstance = bootstrap.Modal.getInstance(modalElement);
      modalInstance?.hide();

      // ✅ Elimina backdrop si quedó pegado
      const backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) backdrop.remove();

      // ✅ Redirige a la vista de empleado
      this.router.navigate(['/empleado']);
    } else {
      // ✅ Mensaje ajustado para coincidir con la prueba unitaria
      this.mensaje = 'Usuario o clave incorrecta.';
    }
  }

  irARecuperar(event: Event) {
    event.preventDefault();

    const modalElement = document.getElementById('loginEmpleadoModal');
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    modalInstance?.hide();

    const backdrop = document.querySelector('.modal-backdrop');
    if (backdrop) backdrop.remove();

    this.router.navigate(['/forgot-password']);
  }
}
