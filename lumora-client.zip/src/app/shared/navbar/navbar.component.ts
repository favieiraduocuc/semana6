import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router'; // 👈 RouterModule agregado
import { LoginClienteComponent } from '../../auth/login-cliente/login-cliente.component';
import { LoginEmpleadoComponent } from '../../auth/login-empleado/login-empleado.component';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule, // 👈 IMPORTANTE para que routerLink funcione
    LoginClienteComponent,
    LoginEmpleadoComponent
  ],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  constructor(private router: Router) {}

  goHome() {
    this.router.navigate(['/']);
  }
}
