import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router'; // 👈 RouterModule agregado
import { LoginComponent } from '../../auth/login/login.component';
import { LoginEmpleadoComponent } from '../../auth/login-empleado/login-empleado.component';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule, // 👈 IMPORTANTE para que routerLink funcione
    LoginComponent,
    LoginEmpleadoComponent
  ],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  constructor(private router: Router) {}

  goHome() {
    this.router.navigate(['/']);
  }
}
