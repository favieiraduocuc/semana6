import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login-empleado',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login-empleado.component.html',
  styleUrls: ['./login-empleado.component.css']
})
export class LoginEmpleadoComponent {
  email: string = '';
  empleadoId: string = '';
  password: string = '';
}
